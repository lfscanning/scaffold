rootProject.name = "simplegradle"

include("app", "lib")
