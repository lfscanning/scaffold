package demo;

public class Lib {
    public static String name() {
        return "lib";
    }
}
