plugins {
    `java-library`
}

dependencies {
    implementation("org.example:testlib:1.0.0")
}
