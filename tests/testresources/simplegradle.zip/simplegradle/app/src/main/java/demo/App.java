package demo;

public class App {
    public static String hello() {
        return "hello";
    }
}
