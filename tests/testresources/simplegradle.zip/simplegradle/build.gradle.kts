// Test project for the Gradle lock file generation tests.
//
// Dependency locking is deliberately NOT configured anywhere in this build, so any
// gradle.lockfile that appears was generated from outside the build.
//
// Dependencies come from the repository in ./localrepo so that resolving them needs no network.
allprojects {
    repositories {
        maven { url = uri("${rootDir}/localrepo") }
    }
}
